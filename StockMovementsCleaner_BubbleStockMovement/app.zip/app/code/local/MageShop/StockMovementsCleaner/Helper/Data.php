<?php

class MageShop_StockMovementsCleaner_Helper_Data extends Mage_Core_Helper_Abstract
{
}
